# دفتر صفقاتي – طريقة الحصول على ملف APK

1. أنشئ حساباً مجانياً على github.com (يمكن من الهاتف).
2. أنشئ مستودعاً جديداً (New repository) باسم TradeJournal.
3. اضغط "uploading an existing file" وارفع كل محتويات هذا المجلد (فك الضغط أولاً)،
   مع الحفاظ على المجلدات كما هي (app و .github).
4. اذهب إلى تبويب Actions ← Build APK، وانتظر 3-5 دقائق حتى تظهر علامة ✓ خضراء.
5. افتح التشغيل ← أسفل الصفحة في Artifacts حمّل TradeJournal-APK ← فك الضغط ← ثبّت app-debug.apk
   (اسمح بالتثبيت من مصادر غير معروفة عند الطلب).

أو: افتح المجلد في Android Studio واضغط Build ← Build APK.
